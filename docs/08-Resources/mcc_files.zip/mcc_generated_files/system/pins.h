/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define PHOTORESISTOR_IN_TRIS                 TRISAbits.TRISA0
#define PHOTORESISTOR_IN_LAT                  LATAbits.LATA0
#define PHOTORESISTOR_IN_PORT                 PORTAbits.RA0
#define PHOTORESISTOR_IN_WPU                  WPUAbits.WPUA0
#define PHOTORESISTOR_IN_OD                   ODCONAbits.ODCA0
#define PHOTORESISTOR_IN_ANS                  ANSELAbits.ANSELA0
#define PHOTORESISTOR_IN_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define PHOTORESISTOR_IN_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define PHOTORESISTOR_IN_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define PHOTORESISTOR_IN_GetValue()           PORTAbits.RA0
#define PHOTORESISTOR_IN_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define PHOTORESISTOR_IN_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define PHOTORESISTOR_IN_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define PHOTORESISTOR_IN_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define PHOTORESISTOR_IN_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define PHOTORESISTOR_IN_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define PHOTORESISTOR_IN_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define PHOTORESISTOR_IN_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA2 aliases
#define DIGITAL_TO_KEITH_TRIS                 TRISAbits.TRISA2
#define DIGITAL_TO_KEITH_LAT                  LATAbits.LATA2
#define DIGITAL_TO_KEITH_PORT                 PORTAbits.RA2
#define DIGITAL_TO_KEITH_WPU                  WPUAbits.WPUA2
#define DIGITAL_TO_KEITH_OD                   ODCONAbits.ODCA2
#define DIGITAL_TO_KEITH_ANS                  ANSELAbits.ANSELA2
#define DIGITAL_TO_KEITH_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define DIGITAL_TO_KEITH_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define DIGITAL_TO_KEITH_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define DIGITAL_TO_KEITH_GetValue()           PORTAbits.RA2
#define DIGITAL_TO_KEITH_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define DIGITAL_TO_KEITH_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define DIGITAL_TO_KEITH_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define DIGITAL_TO_KEITH_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define DIGITAL_TO_KEITH_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define DIGITAL_TO_KEITH_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define DIGITAL_TO_KEITH_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define DIGITAL_TO_KEITH_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RD1 aliases
#define DEBUG_LED_TRIS                 TRISDbits.TRISD1
#define DEBUG_LED_LAT                  LATDbits.LATD1
#define DEBUG_LED_PORT                 PORTDbits.RD1
#define DEBUG_LED_WPU                  WPUDbits.WPUD1
#define DEBUG_LED_OD                   ODCONDbits.ODCD1
#define DEBUG_LED_ANS                  ANSELDbits.ANSELD1
#define DEBUG_LED_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define DEBUG_LED_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define DEBUG_LED_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define DEBUG_LED_GetValue()           PORTDbits.RD1
#define DEBUG_LED_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define DEBUG_LED_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define DEBUG_LED_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define DEBUG_LED_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define DEBUG_LED_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define DEBUG_LED_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define DEBUG_LED_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define DEBUG_LED_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define DEBUG_BUTTON_TRIS                 TRISDbits.TRISD2
#define DEBUG_BUTTON_LAT                  LATDbits.LATD2
#define DEBUG_BUTTON_PORT                 PORTDbits.RD2
#define DEBUG_BUTTON_WPU                  WPUDbits.WPUD2
#define DEBUG_BUTTON_OD                   ODCONDbits.ODCD2
#define DEBUG_BUTTON_ANS                  ANSELDbits.ANSELD2
#define DEBUG_BUTTON_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define DEBUG_BUTTON_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define DEBUG_BUTTON_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define DEBUG_BUTTON_GetValue()           PORTDbits.RD2
#define DEBUG_BUTTON_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define DEBUG_BUTTON_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define DEBUG_BUTTON_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define DEBUG_BUTTON_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define DEBUG_BUTTON_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define DEBUG_BUTTON_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define DEBUG_BUTTON_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define DEBUG_BUTTON_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/